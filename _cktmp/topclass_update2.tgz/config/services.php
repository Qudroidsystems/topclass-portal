<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'resend' => [
        'key' => env('RESEND_KEY'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

    'paystack' => [
        'active'          => env('PAYSTACK_ACTIVE', true),
        'mode'            => env('PAYSTACK_MODE', 'sandbox'),
        'secret_key'      => env('PAYSTACK_SECRET_KEY'),
        'public_key'      => env('PAYSTACK_PUBLIC_KEY'),
        'test_secret_key' => env('PAYSTACK_TEST_SECRET_KEY'),
        'test_public_key' => env('PAYSTACK_TEST_PUBLIC_KEY'),
        'live_secret_key' => env('PAYSTACK_LIVE_SECRET_KEY'),
        'live_public_key' => env('PAYSTACK_LIVE_PUBLIC_KEY'),
    ],

    'twilio' => [
    'sid' => env('TWILIO_SID'),
    'auth_token' => env('TWILIO_AUTH_TOKEN'),
    'phone_number' => env('TWILIO_PHONE_NUMBER'),
],


    // Push notifications to the Vite Schools mobile app (Firebase Cloud Messaging).
    'fcm' => [
        'enabled'     => env('FCM_ENABLED', true),
        'credentials' => env('FCM_CREDENTIALS', storage_path('app/fcm-service-account.json')),
        'project_id'  => env('FCM_PROJECT_ID'),
    ],

    // Lesson reminders pushed to teachers before each class.
    'mobile' => [
        // Which Vite Schools app this portal pairs with: 'dynamic' (assessments set per class
        // category — Vite Schools app) or 'fixed' (CA1, CA2, CA3, Exam — TopClass Schools app).
        'score_model' => 'fixed',
        // Show teachers' phone/e-mail to parents in the app's "Teachers" screen.
        'share_teacher_contacts' => env('MOBILE_SHARE_TEACHER_CONTACTS', true),
        // Show results, report cards, progress and guidance to parents/students in the app.
        'parent_results' => env('MOBILE_PARENT_RESULTS', true),
    ],

    'timetable_reminders' => [
        'minutes' => (int) env('TIMETABLE_REMINDER_MINUTES', 10),
    ],
];
