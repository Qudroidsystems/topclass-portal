<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TimetableOverride extends Model
{
    //
}
